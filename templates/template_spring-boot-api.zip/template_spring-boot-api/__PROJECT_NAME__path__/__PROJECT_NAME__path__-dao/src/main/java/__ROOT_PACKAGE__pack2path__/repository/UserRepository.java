package %ROOT_PACKAGE__pack%.repository;

import %ROOT_PACKAGE__pack%.User;
import org.springframework.data.jpa.repository.JpaRepository;

//import javax.transaction.Transactional;
import org.springframework.transaction.annotation.Transactional;

public interface UserRepository extends JpaRepository<User, Long> {

    User findByUsername(String username);

    User findByEmail(String email);

    int countByUsername(String username);

    int countByEmail(String email);

    @Transactional
    long deleteByUsernameAndEmail(String username, String email);

}
