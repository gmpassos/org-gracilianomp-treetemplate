package %ROOT_PACKAGE__pack%.repository;

import org.junit.Test;

public class BasicTest {

    @Test
    public void test() {

    }

}
