package %ROOT_PACKAGE__pack%;

import org.junit.Test;

public class FooIT {

	@Test
	public void test() {
		
	}

}
