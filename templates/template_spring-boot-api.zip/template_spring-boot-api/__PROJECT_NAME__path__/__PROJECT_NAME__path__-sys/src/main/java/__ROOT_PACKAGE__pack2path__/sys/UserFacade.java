package %ROOT_PACKAGE__pack%.sys;


import %ROOT_PACKAGE__pack%.User;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static org.slf4j.LoggerFactory.getLogger;

@Service
public class UserFacade {

    private static final Logger LOGGER = getLogger( UserFacade.class );
    
    @Autowired
    private UserService userService ;

    public boolean createUser(User user) {
        if ( !user.checkValid() ) return false ;

        if ( userService.containsUsername(user.getUsername()) ) return false ;
        if ( userService.containsEmail(user.getEmail()) ) return false ;

        User save = userService.save(user);
        return save != null ;
    }

    public boolean changePassword(String email, String password) {
        User user = getUserByEmail(email);
        if (user == null) return false ;

        boolean ok = user.definePassword(password);
        if (!ok) return false ;

        if ( !user.checkPasswordDefined() ) return false ;

        userService.save(user);
        return true ;
    }

    public User getUserByUsername(String username) {
        return userService.findByUsername(username);
    }

    public User getUserByEmail(String email) {
        return userService.findByEmail(email);
    }

    public boolean delete(String username, String email) {
        return userService.delete(username, email);
    }

}
