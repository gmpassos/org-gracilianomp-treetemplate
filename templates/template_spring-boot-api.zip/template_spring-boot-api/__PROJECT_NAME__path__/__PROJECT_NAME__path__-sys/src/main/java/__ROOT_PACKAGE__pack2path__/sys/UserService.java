package %ROOT_PACKAGE__pack%.sys;


import %ROOT_PACKAGE__pack%.User;
import %ROOT_PACKAGE__pack%.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository repository ;

    public User findByUsername(String username) {
        return repository.findByUsername(username);
    }

    public User findByEmail(String email) {
        return repository.findByEmail(email);
    }

    public User save(User entity) {
        return repository.save(entity);
    }

    public boolean containsUsername(String username) {
        return repository.countByUsername(username) > 0 ;
    }

    public boolean containsEmail(String email) {
        return repository.countByEmail(email) > 0 ;
    }

    public boolean delete(String username, String email) {
        return repository.deleteByUsernameAndEmail(username, email) > 0 ;
    }

}
