package %ROOT_PACKAGE__pack%.sys;

import org.junit.Test;

public class FooTest {

	@Test
	public void test() {
		
	}

}
