package %ROOT_PACKAGE__pack%.client;

import org.junit.Test;

public class UserClientTest {

    @Test
    public void test() {

    }

}
