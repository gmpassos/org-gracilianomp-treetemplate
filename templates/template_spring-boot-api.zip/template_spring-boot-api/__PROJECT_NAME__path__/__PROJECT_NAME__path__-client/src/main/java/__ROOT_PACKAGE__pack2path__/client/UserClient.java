package %ROOT_PACKAGE__pack%.client;

import %ROOT_PACKAGE__pack%.User;
import feign.Headers;
import feign.Param;
import feign.RequestLine;
import org.springframework.cloud.netflix.feign.FeignClient;

@Headers({"Accept: application/json", "Content-Type: application/json"})
@FeignClient
public interface UserClient {

    static UserClient create(String wsURL) {
        return Feign.builder().target(UserClient.class, wsURL);
    }

    ////////////

    @RequestLine("PUT /user")
    Boolean createUser(User user);

    @RequestLine("GET /user?username={username}")
    User getUserByUsername(@Param("username") String username);

    @RequestLine("GET /user?email={email}")
    User getUserByEmail(@Param("email") String email);

    @RequestLine("DELETE /user?username={username}&email={email}")
    Boolean deleteUser(@Param("username") String username, @Param("email") String email);

}
