package %ROOT_PACKAGE__pack%.client;

import feign.Logger;
import feign.jackson.JacksonDecoder;
import feign.jackson.JacksonEncoder;

import java.util.Arrays;

public class Feign {

    static final private boolean LOG_REQUESTS_TO_CONSOLE = false ;

    public static feign.Feign.Builder builder() {
        return new Builder();
    }

    public static class Builder extends feign.Feign.Builder {

        public Builder() {
            encoder(new JacksonEncoder());
            decoder(new JacksonDecoder());

            if (LOG_REQUESTS_TO_CONSOLE) {
                Logger logger = new Logger() {
                    @Override
                    protected void log(String configKey, String format, Object... args) {
                        System.out.println(">>>>>>>>> " + configKey + " > " + format + " > " + Arrays.toString(args)) ;
                        }
                };
                logger(logger);
                logLevel(Logger.Level.FULL);
            }

        }
    }

}
