package %ROOT_PACKAGE__pack%;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import %ROOT_PACKAGE__pack%.util.*;
import lombok.*;

import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
@ToString
@Table(name = "user")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(unique = true)
    private String username;

    private String email ;

    private String name ;

    private String passwordHash ;

    private boolean disabled ;

    public User(String username, String email, String name, String password) {
        this(username, email, name, password, false) ;
    }

    @Builder
    public User(String username, String email, String name, String password, boolean disabled) {
        setUsername(username);
        setEmail(email);
        setName(name);

        boolean passOk = definePassword(password);

        if (!passOk) {
            throw  new IllegalArgumentException("Invalid Password!") ;
        }
    }

    public void setUsername(String username) {
        if (!UsernameUtil.isValid(username)) throw new IllegalArgumentException("Invalid username: "+ username) ;
        this.username = username;
    }

    public void setEmail(String email) {
        if (!EmailUtil.isValid(email)) throw new IllegalArgumentException("Invalid email: "+ email) ;
        this.email = email;
    }

    public void setName(String name) {
        name = name.replaceAll("\\s+"," ").trim() ;
        if (name == null || name.isEmpty()) throw new IllegalArgumentException("Invalid name: "+ name) ;
        this.name = name;
    }

    public void setPasswordHash(String passwordHash) {
        if (!PasswordUtil.isPasswordHashHex(passwordHash)) throw new IllegalArgumentException("Invalid passwordHash!") ;
        this.passwordHash = passwordHash;
    }

    public void clearPassword() {
        this.passwordHash = null ;
    }

    public void setPassword(String password) {
        definePassword(password) ;
    }

    public String getPassword() {
        return "";
    }

    public boolean checkPasswordDefined() {
        return passwordHash != null && !passwordHash.isEmpty() ;
    }

    public boolean checkPassword(String password) {
        String passwordHash = getPasswordHash();
        if ( passwordHash == null || passwordHash.isEmpty() ) return false ;
        return PasswordUtil.checkPassword( getEmail(), password, passwordHash) ;
    }

    public boolean definePassword(String password) {
        if ( !PasswordUtil.isValid(password) ) return false ;
        String passwordHash = PasswordUtil.hashPasswordHex(getEmail(), password);
        if ( passwordHash == null ) return false ;
        setPasswordHash(passwordHash);
        return true ;
    }

    public boolean checkValid() {
        if ( !checkPasswordDefined() ) return false ;

        if ( username == null || username.isEmpty() ) return false ;
        if ( email == null || email.isEmpty() ) return false ;
        if ( name == null || name.isEmpty() ) return false ;

        return true ;
    }

}
