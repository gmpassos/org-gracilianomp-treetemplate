package %ROOT_PACKAGE__pack%.util;

public class Hex {

    private static final String HEXES = "0123456789ABCDEF" ;
    private static final char[] HEXES_CHARS = HEXES.toCharArray() ;

    static public boolean isHex(String s) {
        if (s == null || s.isEmpty()) return false ;

        int sz = s.length() ;

        for (int i = 0; i < sz; i++) {
            char c = s.charAt(i) ;
            if ( !StringUtil.contains(HEXES_CHARS,c) ) return false ;
        }

        return true ;
    }

    public static byte[] hexToBytes(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }

    public static String bytesToHex(byte[] bs) {
        final StringBuilder hex = new StringBuilder(2 * bs.length);
        for (byte b : bs) {
            char h1 = HEXES.charAt((b & 0xF0) >> 4);
            char h2 = HEXES.charAt((b & 0x0F));
            hex.append(h1).append(h2);
        }
        return hex.toString();
    }

}
