package %ROOT_PACKAGE__pack%.util;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class PasswordUtil {

    static final public int PASSWORD_MINIMAL_LENGTH = 8 ;

    static final public int PASSWORD_HASH_BITS = 256 ;
    static final public int PASSWORD_HASH_BYTES = PASSWORD_HASH_BITS/8 ;
    static final public int PASSWORD_HASH_HEX_LENGTH = PASSWORD_HASH_BYTES*2 ;

    static final public Charset CHARSET_LATIN1 = Charset.forName("LATIN1") ;

    static public boolean isValid(String password) {
        if (password == null) return false ;
        if (password.isEmpty()) return false ;
        if (password.length() < PASSWORD_MINIMAL_LENGTH) return false ;

        if ( !password.trim().equals(password) ) return false ;

        if (!password.matches("^.*?\\d.*$")) return false ;
        if (!password.matches("^.*?[A-Z].*$")) return false ;
        if (!password.matches("^.*?[a-z].*$")) return false ;

        return  true ;
    }

    static public boolean isPasswordHashHex(String passwordHashHex) {
        if (passwordHashHex == null || passwordHashHex.length() != PASSWORD_HASH_HEX_LENGTH ) return false ;
        return Hex.isHex(passwordHashHex) ;
    }

    static private final ThreadLocal<MessageDigest> sha256Instance = new ThreadLocal<>();

    static private MessageDigest getSha256Instance() {
        MessageDigest digest = sha256Instance.get();
        if (digest != null) return digest ;

        try {
            digest = MessageDigest.getInstance("SHA-256");
            sha256Instance.set(digest);
            return digest ;
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("MessageDigest: Can't get SHA-256 instance!",e);
        }
    }

    static public String hashPasswordHex(String email, String password) {
        byte[] hash = hashPassword(email, password);
        return hash != null ? Hex.bytesToHex(hash) : null ;
    }

    static public byte[] hashPassword(String email, String password) {
        if ( !isValid(password) ) return null ;
        String entry = email +":"+ password ;

        byte[] entryBytes = entry.getBytes(CHARSET_LATIN1);

        MessageDigest digest = getSha256Instance();
        digest.reset();
        byte[] hash = digest.digest(entryBytes) ;
        digest.reset();

        return hash ;
    }

    static public boolean checkPassword(String email, String password, String passwordHashHex) {
        if ( !isPasswordHashHex(passwordHashHex) ) return false ;
        return checkPassword(email, password, Hex.hexToBytes(passwordHashHex));
    }

    static public boolean checkPassword(String email, String password, byte[] passwordHash) {
        if (passwordHash == null || passwordHash.length != PASSWORD_HASH_BYTES) return false;
        if ( !isValid(password) ) return false ;

        byte[] hash2 = hashPassword(email, password);
        return Arrays.equals(passwordHash,hash2);
    }

}
