package %ROOT_PACKAGE__pack%.util;

public class UsernameUtil {

    static public boolean isValid(String username) {
        if (username == null) return false ;
        if (username.isEmpty()) return false ;

        if ( !username.trim().equals(username) ) return false ;

        if ( !username.matches("\\w+") ) return false ;

        return true ;
    }

}
