package %ROOT_PACKAGE__pack%.util;

public class StringUtil {

    static public int count(String s, char c) {
        int sz = s.length() ;
        int count = 0 ;

        for (int i = 0; i < sz; i++) {
            if ( s.charAt(i) == c ) count++ ;
        }

        return count ;
    }

    static public boolean contains(String s, char c) {
        int sz = s.length() ;

        for (int i = 0; i < sz; i++) {
            if ( s.charAt(i) == c ) return true ;
        }

        return false ;
    }

    static public boolean contains(char[] s, char c) {
        int sz = s.length ;

        for (int i = 0; i < sz; i++) {
            if ( s[i] == c ) return true ;
        }

        return false ;
    }

    static public int indexOf(String s, char c) {
        int sz = s.length() ;

        for (int i = 0; i < sz; i++) {
            if ( s.charAt(i) == c ) return i ;
        }

        return -1 ;
    }


}
