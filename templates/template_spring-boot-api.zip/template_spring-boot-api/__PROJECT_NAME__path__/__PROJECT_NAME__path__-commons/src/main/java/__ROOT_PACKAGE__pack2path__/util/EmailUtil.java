package %ROOT_PACKAGE__pack%.util;

public class EmailUtil {

    static public boolean isValid(String email) {
        if (email == null) return false ;
        if (email.isEmpty()) return false ;
        if (email.length() < 3) return false ;

        if ( !email.trim().equals(email) ) return false ;

        if ( StringUtil.count(email, '@') != 1 ) return false ;

        int idx = StringUtil.indexOf(email, '@');

        if ( idx < 1 || idx > email.length()-2 ) return false ;

        String domain = email.substring(idx + 1);

        if (domain.length() < 3) return false ;
        if (!domain.contains(".")) return false ;
        if (domain.contains("..")) return false ;

        if ( !email.matches("[@\\w\\.\\-\\+]+") ) return false ;

        return true ;
    }

}
