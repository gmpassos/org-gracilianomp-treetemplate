package %ROOT_PACKAGE__pack%;

import %ROOT_PACKAGE__pack%.util.PasswordUtil;
import org.junit.Assert;
import org.junit.Test;

public class UserTest {

    @Test
    public void createUser() {

        String username = "joe";
        String email = "joe@mail.com";
        String name = "Joe D";
        String password = "SomJoePass123";

        User user = new User(username, email, name, password);

        Assert.assertNotNull( user.getPasswordHash() );

        Assert.assertTrue( user.checkPasswordDefined() );

        String passwordHash = PasswordUtil.hashPasswordHex(email, password);
        Assert.assertEquals( passwordHash, user.getPasswordHash() );

        Assert.assertTrue( passwordHash, user.checkPassword(password) );
        Assert.assertFalse( passwordHash, user.checkPassword("123") );

        Assert.assertTrue( user.checkValid() );

    }

    @Test(expected = IllegalArgumentException.class)
    public void createUserError() {

        User user = new User("joe", "joe@mail.com", "Joe", "badpass");

    }

    @Test
    public void createUser2() {

        String username = "joe";
        String email = "joe@mail.com";
        String name = "Joe";
        String password = "SomJoePass123";

        String passwordHash = PasswordUtil.hashPasswordHex(email, password);

        User user = new User() ;
        user.setUsername(username);
        user.setEmail(email);
        user.setName(name);
        user.setPasswordHash(passwordHash);

        Assert.assertTrue( user.checkPassword(password) );
        Assert.assertFalse( user.checkPassword("SomWrongPass123") );

        Assert.assertEquals(name, user.getName());

    }

    @Test(expected = IllegalArgumentException.class)
    public void createUserError2() {

        String username = "joe";
        String name = "Joe";
        String email = "joe@mail.com";

        User user = new User() ;
        user.setUsername(username);
        user.setEmail(email);
        user.setName(name);
        user.setPasswordHash("01ab");

    }

}
