package %ROOT_PACKAGE__pack%.util;

import org.junit.Assert;
import org.junit.Test;

public class PasswordUtilTest {

    @Test
    public void isValid() {

        Assert.assertFalse(PasswordUtil.isValid(null));
        Assert.assertFalse(PasswordUtil.isValid(""));
        Assert.assertFalse(PasswordUtil.isValid("1"));
        Assert.assertFalse(PasswordUtil.isValid("123456"));

        Assert.assertFalse(PasswordUtil.isValid("a"));
        Assert.assertFalse(PasswordUtil.isValid("abc"));

        Assert.assertFalse(PasswordUtil.isValid("A"));
        Assert.assertFalse(PasswordUtil.isValid("ABC"));

        Assert.assertFalse(PasswordUtil.isValid("sombadpass123"));

        Assert.assertFalse(PasswordUtil.isValid("SomGoodPass"));

        Assert.assertTrue(PasswordUtil.isValid("SomGoodPass123"));

        Assert.assertFalse(PasswordUtil.isValid(" SomGoodPass123 "));

    }

    @Test
    public void hash() {

        Assert.assertNull( PasswordUtil.hashPassword("joe@mail.com" , "123") );

        Assert.assertNotNull( PasswordUtil.hashPassword("joe@mail.com" , "123AbcDefG") );

    }

    @Test
    public void check() {

        String email = "joe@mail.com" ;
        String pass = "SomGoodPass123" ;

        byte[] hash = PasswordUtil.hashPassword(email, pass);
        String hashHex = PasswordUtil.hashPasswordHex(email, pass);

        Assert.assertEquals( hashHex , Hex.bytesToHex(hash) );
        Assert.assertArrayEquals( hash , Hex.hexToBytes(hashHex) );

        Assert.assertTrue( PasswordUtil.checkPassword(email, pass, hashHex) );

        Assert.assertFalse( PasswordUtil.checkPassword(email, pass, "010203") );

        Assert.assertFalse( PasswordUtil.checkPassword(email, "SomErrorPass123", hashHex) );

        Assert.assertFalse( PasswordUtil.checkPassword(email, "123456", hashHex) );

        Assert.assertFalse( PasswordUtil.checkPassword(email, "123456ABCDEFG", hashHex) );


    }
}
