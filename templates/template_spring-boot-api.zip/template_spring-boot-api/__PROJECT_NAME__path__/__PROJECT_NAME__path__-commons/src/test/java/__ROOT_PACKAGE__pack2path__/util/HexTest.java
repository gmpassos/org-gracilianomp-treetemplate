package %ROOT_PACKAGE__pack%.util;

import org.junit.Assert;
import org.junit.Test;

public class HexTest {

    @Test
    public void test() {

        String data = "Some\nSimple\rText !\t! !" ;

        byte[] bytes = data.getBytes();

        String hex = Hex.bytesToHex(bytes);

        byte[] bytes2 = Hex.hexToBytes(hex);

        Assert.assertArrayEquals( bytes, bytes2 );

        Assert.assertTrue( Hex.isHex(hex) );
        Assert.assertFalse( Hex.isHex(data) );

        Assert.assertTrue( Hex.isHex("010203") );
        Assert.assertFalse( Hex.isHex("010203x") );

    }

}
