package %ROOT_PACKAGE__pack%.util;

import org.junit.Assert;
import org.junit.Test;

public class EmailUtilTest {

    @Test
    public void isValid() {

        Assert.assertFalse( EmailUtil.isValid(null) );
        Assert.assertFalse( EmailUtil.isValid("") );
        Assert.assertFalse( EmailUtil.isValid("a@b@c") );

        Assert.assertFalse( EmailUtil.isValid("ab") );
        Assert.assertFalse( EmailUtil.isValid("abc") );
        Assert.assertFalse( EmailUtil.isValid("abcdefg") );

        Assert.assertFalse( EmailUtil.isValid("u@d") );

        Assert.assertFalse( EmailUtil.isValid("u@d..x") );

        Assert.assertFalse( EmailUtil.isValid("@dd.x") );
        Assert.assertFalse( EmailUtil.isValid("uu@") );
        Assert.assertFalse( EmailUtil.isValid("uu@x") );

        Assert.assertFalse( EmailUtil.isValid("u@ddx") );

        Assert.assertFalse( EmailUtil.isValid(" joe@email.com ") );

        Assert.assertFalse( EmailUtil.isValid("joe@ema!il.com") );

        Assert.assertTrue( EmailUtil.isValid("u@d.x") );
        Assert.assertTrue( EmailUtil.isValid("joe@email.com") );

    }

}
