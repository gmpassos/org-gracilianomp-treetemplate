package %ROOT_PACKAGE__pack%.controllers;


import %ROOT_PACKAGE__pack%.User;
import %ROOT_PACKAGE__pack%.sys.UserFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;

@RestController
@RequestMapping(path = "login", produces = MediaType.APPLICATION_JSON_VALUE)
public class LoginController {

    @Autowired
    private UserFacade facade ;

    @GetMapping
    public boolean logout(@RequestParam(value = "username", required = true) String username, HttpSession session) {
        User prevUser = (User) session.getAttribute("prevUser");
        if (prevUser == null) return false ;

        if (username.contains("@")) {
            if ( !prevUser.getEmail().equals(username) ) return false ;
        }
        else {
            if ( !prevUser.getUsername().equals(username) ) return false ;
        }

        closeSession(session);

        return true ;
    }

    @PostMapping
    public User login(@RequestParam(value = "username", required = false) String username, @RequestParam(value = "password", required = false) String password, HttpSession session) {

        if ( username == null || password == null || username.isEmpty() || password.isEmpty() ) {
            User prevUser = (User) session.getAttribute("user");

            if (prevUser != null) {
                User user = facade.getUserByEmail(prevUser.getEmail());

                if ( user != null && !user.isDisabled() ) {
                    openSession(session, user);
                    return user ;
                }
            }

            closeSession(session);
            return null ;
        }

        User user ;

        if (username.contains("@")) {
            user = facade.getUserByEmail(username);
        }
        else {
            user = facade.getUserByUsername(username);
        }

        if ( user == null || user.isDisabled() ) {
            closeSession(session);
            return null ;
        }
        else if ( user.checkPassword(password) ) {
            openSession(session, user);
            return user ;
        }
        else {
            closeSession(session);
            return null ;
        }
    }

    private void closeSession(HttpSession session) {
        session.removeAttribute("user");

        try {
            session.invalidate();
        } catch (Exception e) { }
    }

    private void openSession(HttpSession session, User user) {
        user.clearPassword();

        session.setMaxInactiveInterval(-1);
        session.setAttribute("user", user);
    }

}
