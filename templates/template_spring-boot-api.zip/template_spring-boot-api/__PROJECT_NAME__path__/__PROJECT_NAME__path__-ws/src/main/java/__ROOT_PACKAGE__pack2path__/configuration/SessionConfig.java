package %ROOT_PACKAGE__pack%.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.session.web.context.AbstractHttpSessionApplicationInitializer;
import org.springframework.session.web.http.CookieHttpSessionStrategy;
import org.springframework.session.web.http.DefaultCookieSerializer;
import org.springframework.session.web.http.HttpSessionStrategy;

@Configuration
public class SessionConfig extends AbstractHttpSessionApplicationInitializer {

    public static final int COOKIE_MAX_AGE = 60 * 60 * 24 * 3; // 3 days in seconds

    public SessionConfig() {
        super(SessionConfig.class);

        System.setProperty("spring.session.store-type", "none") ;
    }

    @Bean
    public HttpSessionStrategy httpSessionStrategy() {
        CookieHttpSessionStrategy cookieHttpSessionStrategy = new CookieHttpSessionStrategy();
        DefaultCookieSerializer cookieSerializer = new DefaultCookieSerializer();

        // 3 days:
        cookieSerializer.setCookieMaxAge(COOKIE_MAX_AGE);

        cookieHttpSessionStrategy.setCookieSerializer(cookieSerializer);
        return cookieHttpSessionStrategy;
    }

}
