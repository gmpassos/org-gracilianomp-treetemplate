package %ROOT_PACKAGE__pack%.controllers;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "uppinfo")
public class InfoController {

    @GetMapping
    public String infoGet() {
        return infos(null) ;
    }

    @PostMapping
    public String infoPost(@RequestBody String body) {
        return infos(body) ;
    }

    private String infos(String body) {
        StringBuilder str = new StringBuilder();

        str.append("Time: "+ System.currentTimeMillis());
        str.append("\n");

        Runtime runtime = Runtime.getRuntime();

        str.append("maxMemory: "+ runtime.maxMemory());
        str.append("\n");
        str.append("usedMemory: "+ ( runtime.maxMemory() - runtime.freeMemory()) );
        str.append("\n");
        str.append("freeMemory: "+ runtime.freeMemory());
        str.append("\n");
        str.append("<<<\n");
        str.append(body);
        str.append(">>>\n");

        return str.toString() ;
    }

}
