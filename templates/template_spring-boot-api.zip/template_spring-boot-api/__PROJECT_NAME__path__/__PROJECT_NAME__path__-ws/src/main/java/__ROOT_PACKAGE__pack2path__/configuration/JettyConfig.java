package %ROOT_PACKAGE__pack%.configuration;

import org.eclipse.jetty.server.AbstractConnector;
import org.eclipse.jetty.server.Connector;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.SessionIdManager;
import org.eclipse.jetty.server.session.DefaultSessionIdManager;
import org.eclipse.jetty.server.session.SessionHandler;
import org.springframework.boot.context.embedded.jetty.JettyEmbeddedServletContainerFactory;
import org.springframework.boot.context.embedded.jetty.JettyServerCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.SessionCookieConfig;
import java.util.Set;

import static java.util.concurrent.TimeUnit.MINUTES;

@Configuration
class JettyConfig {

    private static final long IDLE_TIMEOUT = MINUTES.toMillis(5);

    @Bean
    public JettyEmbeddedServletContainerFactory getJettyEmbeddedServletContainerFactory() {
        JettyEmbeddedServletContainerFactory factory = new JettyEmbeddedServletContainerFactory();

        JettyServerCustomizer serverCustomizer = getJettyServerCustomizer();
        factory.addServerCustomizers(serverCustomizer);

        return factory;
    }

    private JettyServerCustomizer getJettyServerCustomizer() {
        return (server) -> {
            configureConnectors(server);
            configureCookies(server);
        };
    }

    private void configureConnectors(Server server) {
        Connector[] connectors = server.getConnectors();

        for (Connector connector : connectors) {
            if ( connector instanceof AbstractConnector) {
                AbstractConnector abstractConnector = (AbstractConnector) connector;
                abstractConnector.setIdleTimeout(IDLE_TIMEOUT);
            }
        }
    }

    private void configureCookies(Server server) {
        SessionIdManager sessionIdManager = server.getSessionIdManager();

        if (sessionIdManager == null) {
            sessionIdManager = new DefaultSessionIdManager(server);
            server.setSessionIdManager(sessionIdManager);
        }

        Set<SessionHandler> sessionHandlers = sessionIdManager.getSessionHandlers();

        for (SessionHandler sessionHandler : sessionHandlers) {
            SessionCookieConfig cookieConfig = sessionHandler.getSessionCookieConfig();
            cookieConfig.setMaxAge( SessionConfig.COOKIE_MAX_AGE );
        }
    }

}