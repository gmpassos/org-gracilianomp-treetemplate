package %ROOT_PACKAGE__pack%.configuration;

import org.eclipse.jetty.server.AbstractConnector;
import org.eclipse.jetty.server.Connector;
import org.eclipse.jetty.server.NetworkConnector;
import org.eclipse.jetty.server.Server;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.boot.context.embedded.jetty.JettyEmbeddedServletContainerFactory;
import org.springframework.boot.context.embedded.jetty.JettyServerCustomizer;

import java.util.Collection;

import static java.util.concurrent.TimeUnit.MINUTES;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

public class JettyConfigTest {

    @Mock
    private Server server;

    @Mock
    private AbstractConnector abstractConnector;

    @Mock
    private NetworkConnector networkConnector;

    @Before
    public void before() {
        initMocks(this);
    }

    @Test
    public void getJettyEmbeddedServletContainerFactory() {
        when(server.getConnectors()).thenReturn(new Connector[] {abstractConnector, networkConnector});

        JettyConfig jettyConfig = new JettyConfig();
        JettyEmbeddedServletContainerFactory factory = jettyConfig.getJettyEmbeddedServletContainerFactory();
        Collection<JettyServerCustomizer> serverCustomizers = factory.getServerCustomizers();
        assertThat(serverCustomizers.size(), equalTo(1));

        JettyServerCustomizer customizer = serverCustomizers.iterator().next();
        customizer.customize(server);

        verify(server).getConnectors();
        
        verify(abstractConnector).setIdleTimeout(MINUTES.toMillis(5));
        verifyNoMoreInteractions(abstractConnector);

        verifyZeroInteractions(networkConnector);
    }
}