package %ROOT_PACKAGE__pack%.controllers;

import org.junit.Test;

public class UserControllerTest {

    @Test
    public void test() {

    }

}
