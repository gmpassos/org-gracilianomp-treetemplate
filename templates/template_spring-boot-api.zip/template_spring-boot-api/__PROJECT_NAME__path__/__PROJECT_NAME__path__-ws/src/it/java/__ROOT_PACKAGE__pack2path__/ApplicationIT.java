package %ROOT_PACKAGE__pack%;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.Setter;
import org.junit.BeforeClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;

public abstract class ApplicationIT {

    @Value("http://localhost:${local.server.port}")
    @Getter
    String host;

    @Getter
    @Setter
    RestOperations restTemplate = new RestTemplate();

    @Autowired
    protected WebApplicationContext webApplicationContext;

    protected MockMvc mockMvc;

    private final static ObjectMapper mapper = new ObjectMapper();

    @BeforeClass
    public static void beforeClass() {
        System.setProperty("image.storage.url", "http://localhost:8097");
    }

    public static String toJson(Object obj) throws JsonProcessingException {
        return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
    }

    public static <T> T toObject(String value, Class<T> clazz) throws IOException {
        return mapper.readValue(value, clazz);
    }

}
