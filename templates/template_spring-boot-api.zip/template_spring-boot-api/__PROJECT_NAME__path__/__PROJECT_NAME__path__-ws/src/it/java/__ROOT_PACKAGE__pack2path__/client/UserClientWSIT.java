package %ROOT_PACKAGE__pack%.client;

import %ROOT_PACKAGE__pack%.Application;
import %ROOT_PACKAGE__pack%.ApplicationIT;
import %ROOT_PACKAGE__pack%.User;
import %ROOT_PACKAGE__pack%.util.PasswordUtil;
import feign.FeignException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.lang.reflect.Field;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT, classes = Application.class)
@ActiveProfiles("test")
public class UserClientWSIT extends ApplicationIT {

    @Test
    public void createUser() {

        UserClient client = UserClient.create("http://localhost:8090");

        String username = "joe";
        String email = "joe@mail.com";
        String name = "Joe D";
        String password = "SomJoePass123";

        User user = new User(username, email, name, password);

        Assert.assertNotNull( user.getPasswordHash() );

        boolean okUser = client.createUser(user) ;
        Assert.assertTrue(okUser);

        User user1 = client.getUserByUsername(username);
        Assert.assertNotNull( user1 );
        Assert.assertTrue( user1.getId() > 0 );
        Assert.assertEquals( username, user1.getUsername() );

        user.setId(user1.getId());

        Assert.assertEquals( user , user1 );

        User user2 = client.getUserByEmail(email);
        Assert.assertNotNull( user2 );
        Assert.assertTrue( user2.getId() > 0 );
        Assert.assertEquals( user , user2 );
        Assert.assertEquals( username, user1.getUsername() );
        Assert.assertEquals( email, user1.getEmail() );
        Assert.assertEquals( name, user1.getName() );

        String passwordHash = PasswordUtil.hashPasswordHex(email, password);

        Assert.assertEquals( passwordHash, user1.getPasswordHash() );

        Assert.assertTrue( user1.checkPassword(password) );


    }

    @Test(expected = FeignException.class)
    public void createUserError() {

        UserClient client = UserClient.create("http://localhost:8090");

        String username = "john";
        String email = "john@mail.com";
        String name = "Joe D";
        String password = "SomJohnPass123";

        User user = new User(username, email, name, password);

        setFieldPasswordHash(user, "010203") ;

        Assert.assertNotNull( user.getPasswordHash() );

        boolean okUser = client.createUser(user) ;
        Assert.assertFalse(okUser);

    }

    static private void setFieldPasswordHash(User user, String passwordHash) {

        try {
            Field field = User.class.getDeclaredField("passwordHash");
            field.setAccessible(true);

            field.set(user, passwordHash);
        }
        catch (Exception e) {
            throw new IllegalStateException("Can't set field passwordHash", e) ;
        }

    }

}