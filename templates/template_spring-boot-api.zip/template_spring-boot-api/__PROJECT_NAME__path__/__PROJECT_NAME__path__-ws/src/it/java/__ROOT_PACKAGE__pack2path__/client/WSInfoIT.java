package %ROOT_PACKAGE__pack%.client;

import %ROOT_PACKAGE__pack%.Application;
import %ROOT_PACKAGE__pack%.ApplicationIT;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT, classes = Application.class)
@ActiveProfiles("test")
public class WSInfoIT extends ApplicationIT {

    public static final String URL_HEALTH = "http://localhost:8090/health";
    public static final String URL_INFO = "http://localhost:8090/uppinfo";

    @Test
    public void testHealth() throws IOException {

        HttpURLConnection connection = createConnection(URL_HEALTH);
        String content = getContentAsString(connection.getInputStream());

        System.out.println("<<"+content+">>");

        Assert.assertTrue(content.trim().length() > 2);

    }

    @Test
    public void testInfoGet() throws IOException {

        HttpURLConnection connection = createConnection(URL_INFO);
        String content = getContentAsString(connection.getInputStream());

        System.out.println("<<"+content+">>");

        Assert.assertTrue(content.contains("Time:"));

    }

    @Test
    public void testInfoPost() throws IOException {
        String content = testInfo(0);

        System.out.println("<<"+content+">>");

        Assert.assertTrue(content.contains("Time:"));
    }

    @Test
    public void testInfoPostSlow() throws IOException {
        String content = testInfo(50);

        System.out.println("<<"+content+">>");

        Assert.assertTrue(content.contains("Time:"));
    }

    private String testInfo(int byteTimeInterval) throws IOException {

        String json = "{ \"test\": true }";

        byte[] jsonBytes = json.getBytes();

        URL url = new URL(URL_INFO);

        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setDoOutput(true);
        conn.setInstanceFollowRedirects(false);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("charset", "utf-8");
        conn.setRequestProperty("Content-Length", Integer.toString(jsonBytes.length));

        conn.setUseCaches(false);

        OutputStream connOut = conn.getOutputStream();

        if (byteTimeInterval > 0) {
            System.out.println("<<<<<<<<<<<<<<<< SENDING BYTES...");
        }

        for (int i = 0; i < jsonBytes.length; i++) {
            byte b = jsonBytes[i];
            connOut.write(b);
            if (byteTimeInterval > 0) {
                connOut.flush();

                System.out.println(((char) (b & 0xff)));

                try {
                    Thread.sleep(byteTimeInterval);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        if (byteTimeInterval > 0) {
            System.out.println("\n>>>>>>>>>>>>>>>>");
        }

        connOut.flush();

        InputStream connIn = conn.getInputStream();

        StringBuilder content = new StringBuilder();
        for (int c; (c = connIn.read()) >= 0; ) {
            content.append((char) c);
        }

        return content.toString();
    }

    private HttpURLConnection createConnection(String urlPath) throws IOException {

        URL url = new URL(urlPath);

        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setDoOutput(true);
        conn.setInstanceFollowRedirects(false);
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("charset", "utf-8");

        return conn;
    }

    private String getContentAsString(InputStream content) throws IOException {
        InputStreamReader in = new InputStreamReader(content);
        StringBuffer text = new StringBuffer();
        BufferedReader buff = new BufferedReader(in);
        String line;
        do {
            line = buff.readLine();
            if (line != null) text.append(line + "\n");
        } while (line != null);

        return text.toString();
    }

}
