%PROJECT_NAME__title%
=============================

The project...

## USAGE:


```

import %ROOT_PACKAGE__pack%.*;


...

  %MAIN_CLASS% o = new %MAIN_CLASS%() ;

...



```


## TODO:

* Define the project README (this file).

## Author

%OWNER% <%OWNER_EMAIL%>

## License

MIT license.
