package %ROOT_PACKAGE__pack%;

import org.junit.*;

public class %MAIN_CLASS%Test {

    @Test
    public void test() {
        
        Assert.assertTrue( true );

    }

}
