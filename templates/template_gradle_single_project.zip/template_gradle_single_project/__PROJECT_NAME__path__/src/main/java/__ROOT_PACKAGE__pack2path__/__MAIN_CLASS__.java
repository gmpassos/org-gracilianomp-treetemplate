package %ROOT_PACKAGE__pack%;

import java.util.Arrays;

public class %MAIN_CLASS% {

    static public void main(String[] args) {
        System.out.println( "Hello World: "+ Arrays.toString(args) );
    }

}
